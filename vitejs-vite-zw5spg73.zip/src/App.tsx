import React from 'react';
import './App.css';

function App() {
  return (
    <div className="main-wrapper">
      
      <section className="hero">
        <div className="hero-text">
          <h1>Join the CometChat partner universe</h1>
          <p>
            Create value for your clients, leveraging our world-class
            technology. Partner with us and grow your business!
          </p>
        </div>

        <div className="hero-form">
          <h2>Became a partner</h2>
          <input type="text" placeholder="Type your name here..." />
          <input type="email" placeholder="📧 Type your emailsomething..." />
          <input type="text" placeholder="Type your company’s name" />
          <button>Submit application</button>
        </div>
      </section>

      
      <section className="logos">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg"
          alt="AWS"
        />
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg"
          alt="Microsoft"
        />
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/4/4e/Cisco_logo_blue_2016.svg"
          alt="Cisco"
        />
       
      </section>

      
      <section className="advantages-heading">
        <span>Be a partner</span>
        <h2>CometChat partner advantages</h2>
      </section>

     
      <section className="advantages-grid">
        <div className="advantage-card">
          <h3>Free credits</h3>
          <p>Empowering partners to scale.</p>
        </div>
        <div className="advantage-card">
          <h3>Revenue share</h3>
          <p>Get monthly recurring revenues when you refer clients.</p>
        </div>
        <div className="advantage-card">
          <h3>Training and mentoring sessions</h3>
          <p>Enabling partners to deliver the best experience.</p>
        </div>
        <div className="advantage-card">
          <h3>Special developer access</h3>
          <p>Build unlimited PoCs for your clients.</p>
        </div>
        <div className="advantage-card">
          <h3>Reduced time</h3>
          <p>Deliver faster with our partner programs.</p>
        </div>
        <div className="advantage-card">
          <h3>On-demand support</h3>
          <p>Technical assistance for implementation.</p>
        </div>
        
      </section>
      <section className="partnership-programs">
        <div className="section-header">
          <p className="subheading">Our programs</p>
          <h2>Types of partnerships programs</h2>
        </div>
        <div className="program-cards">
          <div className="program-card">
            <span className="icon">✅</span>
            <h3>Affiliate partner program</h3>
            <p>
              Bring value to your customers with a world-class in-app messaging
              tool that increases user-to-user engagement and retention. Get
              incentivized for referring CometChat to any of your customers.
            </p>
          </div>
          <div className="program-card">
            <span className="icon">💻</span>
            <h3>Technology partner program</h3>
            <p>
              Development teams can use our plug and play solution to build top
              class chat solutions for their clients using our SDKs and APIs.
              It’s simple, safe and secure!
            </p>
          </div>
          <div className="program-card">
            <span className="icon">🚀</span>
            <h3>Start up growth program</h3>
            <p>
              We help incubators, accelerators, co-working space that foster an
              ecosystem of start-ups. This program also enables VCs to
              accelerate the growth of their portfolio companies.
            </p>
          </div>
        </div>
      </section>
      <section className="faq-section">
  <h4 className="faq-label">FAQ’s</h4>
  <h2 className="faq-heading">We want to help you<br />with all your doubts</h2>

  <div className="faq-container">
    <details open>
      <summary>This is a frequently asked question?</summary>
      <p>
        Lorem ipsum dolor sit amet consectetur. Tellus eget consequat tortor odio...
      </p>
    </details>
    <details>
      <summary>This is a frequently asked question?</summary>
    </details>
    <details>
      <summary>
        This is a very long frequently asked question about our services with more than one line?
      </summary>
    </details>
    <details>
      <summary>This is a frequently asked question?</summary>
    </details>
    <details>
      <summary>This is a question?</summary>
    </details>
    <details>
      <summary>This is a question?</summary>
    </details>
  </div>
</section>
<section className="cta-section">
  <h2>Get started for free</h2>
  <p>
    Build and test for as long as you need. <br />
    Pick a plan when you’re ready.
  </p>
  <div className="cta-buttons">
    <button className="btn-dark">Start free trial</button>
    <button className="btn-purple">Schedule a demo</button>
  </div>
</section>

<div className="app">
      <section className="hero">
        <h1>Join the CometChat partner universe</h1>
        <p>
          Create value for your clients, leveraging our world-class technology.
          Partner with us and grow your business!
        </p>
        <div className="form-container">
          <h3>Become a partner</h3>
          <input type="text" placeholder="Type your name here..." />
          <input type="email" placeholder="Type your email..." />
          <input type="text" placeholder="Type your company’s name" />
          <button>Submit application</button>
        </div>
      </section>

      <section className="logos">
        <img src="your-image-url-1.png" alt="Logo 1" />
        <img src="your-image-url-2.png" alt="Logo 2" />
        {/* Add more logos if needed */}
      </section>

      <section className="benefits">
        <h2>The benefits</h2>

        <div className="benefit-item">
          <h3>Free credits</h3>
          <p>Empowering partners to scale.</p>
        </div>

        <div className="benefit-item">
          <h3>Revenue share</h3>
          <p>Get monthly recurring revenues when you refer clients.</p>
        </div>

        <div className="benefit-item">
          <h3>Training and mentoring sessions</h3>
          <p>Enabling partners to deliver the best experience.</p>
        </div>

        <div className="benefit-item">
          <h3>Special developer access</h3>
          <p>Get an all-access account to build unlimited PoCs for your clients.</p>
        </div>

        <div className="benefit-item">
          <h3>Reduced time</h3>
          <p>Deliver your products much faster with our partners’ programs.</p>
        </div>

        <div className="benefit-item">
          <h3>Value addition to your users</h3>
          <p>Provide enhanced offerings and features to retain more customers.</p>
        </div>

        <div className="benefit-item">
          <h3>Knowledge sessions</h3>
          <p>Access to product and market sessions.</p>
        </div>

        <div className="benefit-item">
          <h3>On-demand support</h3>
          <p>Technical assistance for implementation.</p>
        </div>

        <div className="benefit-item">
          <h3>Significant passive income</h3>
          <p>Earn recurring income with minimal effort once set up.</p>
        </div>
      </section>
    </div>
    
<footer className="footer-grid">
  <div className="footer-columns">
    <div>
      <h4>Platform</h4>
      <ul>
        <li>Features</li>
        <li>Chat & Messaging</li>
        <li>Voice & Video Calls</li>
        <li>Security & Compliance</li>
        <li>Extensions</li>
      </ul>
    </div>
    <div>
      <h4>Solutions</h4>
      <ul>
        <li>Social Community</li>
        <li>Marketplace</li>
        <li>Healthcare</li>
        <li>Education</li>
      </ul>
    </div>
    <div>
      <h4>Developers</h4>
      <ul>
        <li>React</li>
        <li>Angular</li>
        <li>Vue</li>
        <li>React Native</li>
      </ul>
    </div>
    <div>
      <h4>Resources</h4>
      <ul>
        <li>Customer stories</li>
        <li>Blog</li>
        <li>Help center</li>
        <li>Partners</li>
      </ul>
    </div>
    <div>
      <h4>Company</h4>
      <ul>
        <li>About us</li>
        <li>Careers</li>
        <li>Pricing</li>
        <li>Chat with us</li>
      </ul>
    </div>
  </div>

  <div className="footer-bottom">
    <p>© 2023 © CometChat</p>
    <div className="footer-socials">
      <span>Facebook</span> · <span>Instagram</span> · <span>GitHub</span>
    </div>
  </div>
</footer>

    </div>
  );
}

export default App;
